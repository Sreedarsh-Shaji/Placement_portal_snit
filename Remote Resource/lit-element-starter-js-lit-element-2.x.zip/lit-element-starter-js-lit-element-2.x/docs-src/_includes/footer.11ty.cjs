module.exports = function(data) {
  return `
<footer>
  <p>
    Made with
    <a href="https://github.com/PolymerLabs/lit-element-starter-js">lit-element-starter-js</a>
  </p>
</footer>`;
};
