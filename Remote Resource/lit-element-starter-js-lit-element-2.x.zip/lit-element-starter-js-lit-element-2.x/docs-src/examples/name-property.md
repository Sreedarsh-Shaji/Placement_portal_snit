---
layout: example.11ty.cjs
title: <my-element> ⌲ Examples ⌲ Name Property
tags: example
name: Name Property
description: Setting the name property
---

<my-element name="Earth"></my-element>

<h3>HTML</h3>

```html
<my-element name="Earth"></my-element>
```
